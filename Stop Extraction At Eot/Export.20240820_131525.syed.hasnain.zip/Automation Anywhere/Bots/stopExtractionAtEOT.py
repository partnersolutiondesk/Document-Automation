import json

def get_column_name(filepath):
    with open(filepath, 'r',encoding='utf-8') as file:
        extraction_result = json.load(file)
    # Navigate through the JSON to extract the columnName
        y = extraction_result["engineData"]["extractionResult"]["tableFeatures"][0]["endOfTableIndicator"]["text"]
    return y

def row_delete(args):
    try:
        # Load the JSON data
        data = json.loads(args[0],strict = False)
        end_of_table_value = get_column_name(args[1])

        # Get the "table" array
        table_array = data["tables"]["table"]

        # Create a new list for updated table items
        updated_table = []
        i = 0
        while i < len(table_array):
            current_entry = table_array[i]
            if(
                    current_entry["Date"]["value"] == end_of_table_value or
                    current_entry["Reference"]["value"] == end_of_table_value or
                    current_entry["description"]["value"] == end_of_table_value or
                    current_entry["Allocated To"]["value"] == end_of_table_value or
                    current_entry["Debit"]["value"] ==end_of_table_value or
                    current_entry["Credit"]["value"] ==end_of_table_value or
                    current_entry["Alloc Balance"]["value"] ==end_of_table_value
            ):

                break

            elif(current_entry["Date"]["value"] == "" and
            current_entry["Reference"]["value"] == "" and
            current_entry["description"]["value"] == "" and
            current_entry["Allocated To"]["value"] == "" and
            current_entry["Debit"]["value"] =="" and
            current_entry["Credit"]["value"] =="" and
            current_entry["Alloc Balance"]["value"] ==""

            ):

            # Check if quantity, total price, and unit price are zero

                # Append the description to the previous line item
                pass
            else:
                # Append the current entry to the updated_table
                updated_table.append(current_entry)

            i += 1

            # Update the "table" array with the filtered list
        data["tables"]["table"] = updated_table

        # Print the updated JSON data
        updated_json = json.dumps(data, indent=3)
        return updated_json

    except Exception as e:
        return "Error:", e


# args[0] = getDocumentJson
# args[1] = filePath

#row_delete(args)